var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/General": {
                    "positions": "1,17,desktop:/trash.desktop,0,1,desktop:/Home.desktop,0,0",
                    "showToolbox": "false",
                    "sortMode": "-1"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
        {
            "alignment": "left",
            "applets": [
                {
                    "config": {
                        "/Configuration": {
                            "PreloadWeight": "100"
                        },
                        "/General": {
                            "favoritesPortedToKAstats": "true",
                            "menuItems": "bookmark:t,application:t,computer:t,leave:t,oftenUsed:f,used:f"
                        },
                        "/Shortcuts": {
                            "global": "Alt+F1"
                        }
                    },
                    "plugin": "org.kde.plasma.kickoff"
                },
                {
                    "config": {
                        "/General": {
                            "middleClickAction": "NewInstance",
                            "showOnlyCurrentDesktop": "true",
                            "showOnlyCurrentScreen": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.icontasks"
                },
                {
                    "plugin": "org.kde.plasma.systemtray"
                },
                {
                    "config": {
                        "/Configuration/Appearance": {
                            "showDate": "true"
                        }
                    },
                    "plugin": "org.kde.plasma.digitalclock"
                }
            ],
            "config": {
                "/": {
                    "formfactor": "2",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                }
            },
            "height": 2,
            "hiding": "normal",
            "location": "bottom",
            "maximumLength": 106.66666666666667,
            "minimumLength": 106.66666666666667,
            "offset": 0
        }
    ],
    "serializationFormatVersion": "1"
}
;

var general = ConfigFile("plasma-org.kde.plasma.desktop-appletsrc", "General");
general.writeEntry("immutability", "2");

plasma.loadSerializedLayout(layout);
